# AMS Simulator of CLup project.

Group members: 
- Riccio Vincenzo (C.P. 10804402); 
- Sorrentino Giancarlo (C.P. 10800065);
- Triuzzi Emanuele (C.P. 10794440).
