# iOS CLup Customer Mobile Application
CLup project.  
Group members: Riccio Vincenzo, Sorrentino Giancarlo, Triuzzi Emanuele

Developed with XCode 12, using Swift+SwiftUI. Target device: iPhone 11
